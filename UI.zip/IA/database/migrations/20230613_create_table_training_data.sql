-- Criação da tabela TrainingData
CREATE TABLE training_data (
    id SERIAL PRIMARY KEY,
    input_data TEXT,
    target_data TEXT
);
